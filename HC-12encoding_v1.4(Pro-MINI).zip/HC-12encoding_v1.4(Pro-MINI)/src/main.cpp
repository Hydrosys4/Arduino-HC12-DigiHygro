
// Software Version V1.2 (added AT commands setting)
// Software Version V1.3 (Support FU4 UART baudrate 1200 as preferred)
// Software Version V1.4 (fixed the case of transmission with char=\x00)

#include "Arduino.h"
#include <SimpleSleep.h>
#include "SoftwareSerial.h"

SimpleSleep Sleep; 

void(* resetFunc) (void) = 0;//declare reset function at address 0

// ################################################################################################################
// HC12 Arduino PIN Setting part  *********************************************************************************
#define HC12RXPIN   11           // PIN 2 reliée au RX du HC12
#define HC12TXPIN   10          // PIN 3 reliée au TX du HC12
#define HC12SETPIN  6           // PIN 4 reliée au SET du HC12
 
// End Setting ****************************************************************************************************
// ################################################################################################################

SoftwareSerial HC12Serial(HC12TXPIN, HC12RXPIN);  
// battery voltage reference
const float InternalReferenceVoltage = 1.105; 

// serial receiver buffer
const byte numChars = 45;   // softwareserial buffer should be 64 so not exceeding the buffer size
char messageRx[numChars+1]="";   // an array to store the received data


// slowwire START 

// global variables

#define slowwire_TIMEOUT      120   // do not change

// ################################################################################################################
// SlowWire Arduino Number of sensor and chiper key  part  ********************************************************

#define slowwire_MAX_SENSORS   2    // Number of Slowwire sensors defined and conected
#define SLEEP_TIME_mSEC   60000    // example 1800000 is 30 minutes


char cipherkey[]="default";   // chipher key
// wireless parameters Setting

char AT_TX_mode[]="AT+FU4"; // format AT+FUx possible values "AT+FU3","AT+FU4" (FU4 is used for long distance transmssion)
char AT_TX_power[]="AT+P3"; // format  AT+Px where X ranges from 1 to 8
char AT_Channel[]="AT+C003"; // format  AT+Cxxx where xxx range from 001 to 100

// End Setting ****************************************************************************************************
// ################################################################################################################


uint8_t sw_data[5];
uint8_t sw_sensor_num = 0;

struct slowwireSTRUCT {
  long humidity = -1;
  long bits = 0;
  uint16_t pin = 0;
  char nameID[10]="";
} slowwire[slowwire_MAX_SENSORS];

int HC12ok = 0;

char message[50]="";
char timestamp[14]="";

void slowwireInit(void)
{

sw_sensor_num=slowwire_MAX_SENSORS;  // should be lower or equal to the slowwire_MAX_SENSORS defined above

// ################################################################################################################
// SlowWire Arduino Define Sensor part  ***************************************************************************

// sensor 1
slowwire[0].pin=3;  // Arduino PIN where the DAT connecotr of te SlowWire is connected
strcpy(slowwire[0].nameID, "primo");  // change "primo" with the name you want to assign to this sensor

// sensor 2
slowwire[1].pin=4;  // Arduino PIN where the DAT connecotr of te SlowWire is connected
strcpy(slowwire[1].nameID, "secondo"); // change "secondo" with the name you want to assign to this sensor


// End Setting ****************************************************************************************************
// ################################################################################################################
  
  uint8_t sensorinde=0;
  for (sensorinde=0 ; sensorinde<sw_sensor_num; sensorinde++) {

    //Serial.println("NemaID: "+ slowwire[sensorinde].nameID + " Pin: " + String(slowwire[sensorinde].pin));
    Serial.println(slowwire[sensorinde].nameID);
  }
}



bool slowwireWaitState(uint8_t level, uint8_t sensorinde)
{
  unsigned long timeout = micros() + 50000;
  while (digitalRead(slowwire[sensorinde].pin) != level) {

    if (micros() > timeout) {
      return false;
    }
    delayMicroseconds(50);
  }
  return true;
}

static uint8_t Compute_CRC8_Simple(uint8_t* byte,int numbytes)  // generates 8 bit CRC from a given array of bytes
{
    const uint8_t generator = 0x1D;
    uint8_t crc = 0; /* start with 0 so first byte can be 'xored' in */
	uint8_t currByte =0 ;
    for (int i=0; i<numbytes; i++) 
    {
		currByte=byte[i];
        crc ^= currByte; /* XOR-in the next input byte */

        for (int i = 0; i < 8; i++)
        {
            if ((crc & 0x80) != 0)
            {
                crc = (uint8_t)((crc << 1) ^ generator);
            }
            else
            {
                crc <<= 1;
            }
        }
    }

    return crc;
}


bool slowwireRead(uint8_t sensorinde)
{

  slowwire[sensorinde].bits = 0;
  sw_data[0] = sw_data[1] = sw_data[2] = sw_data[3] = sw_data[4] = 0;
  slowwire[sensorinde].humidity = -1;

  uint32_t numcycles=100;
  uint8_t count_ext=0;
  uint32_t count = numcycles;
  while ((count_ext<3)&&(count>=numcycles)) {

    pinMode(slowwire[sensorinde].pin, OUTPUT);

    delay(100);
    digitalWrite(slowwire[sensorinde].pin, HIGH);

    delay(5);

    digitalWrite(slowwire[sensorinde].pin, LOW);

    delay(19);  // minimum 18ms

    digitalWrite(slowwire[sensorinde].pin, HIGH);

    delay(10);
    pinMode(slowwire[sensorinde].pin, INPUT);
    digitalWrite(slowwire[sensorinde].pin, HIGH);       // turn on pullup resistors

 // Wait for sensor to pull pin low.
    count = 0;
    while ((digitalRead(slowwire[sensorinde].pin) != 0)&&(count<numcycles)) {
      count++;
      delay(3);
    }
    //Serial.println(String(count) + " PIN " + String(slowwire[sensorinde].pin));
    count_ext++;

  }
  if (count>=numcycles)
  {  
      return false; 
  }

  // for debug check if the system gets answer
  //slowwire[sensorinde].humidity=count;
  // pin is now zero
  //noInterrupts();
  // signal is made in the way that one bit is transmitted with a low pulse and a high pulse
  // when 1 the high pulse is 1/4 the lenght of the low pulse, 
  // when 0 the high pulse is the same lenght of the low pulse
  // low pulse lenght is constant to 10ms
  //noInterrupts();

  int i;

    for (i = -1; i < 40; i++) {
      if (!slowwireWaitState(1,sensorinde)) { break; }
      delay(6);                          // 8 seem to be OK
      
      if (i>=0){
        if (digitalRead(slowwire[sensorinde].pin)==0) {           
        //sw_data[i / 8] |= (1 << (7 - i % 8));        
        sw_data[i / 8] |= (1 << (i % 8));        
        }
      }
      if (!slowwireWaitState(0,sensorinde)) { break; }
    }

  pinMode(slowwire[sensorinde].pin, INPUT);

  //digitalWrite(slowwire[sensorinde].pin, HIGH);

  //interrupts();
  slowwire[sensorinde].bits = i;
  if (i < 16) { return false; }
 
  
  if ((Compute_CRC8_Simple(sw_data,2)-sw_data[2])==0) {
    slowwire[sensorinde].humidity = ((sw_data[1] << 8) | sw_data[0]);
    return true;
  }



  return false;
}





// SLOWWIRE END *************


unsigned int readSerialHC12() {
    unsigned int ndx = 0;
    unsigned int count = 0;
    char rc;
    while ((HC12Serial.available() > 0)&&(count<200)) {
      count++;
      rc = HC12Serial.read();
      if (ndx < numChars) {      
        //Serial.println(rc);
        messageRx[ndx] = rc;
        ndx++;
        }
      delay(50);
        
    }
    messageRx[ndx] = '\0'; // terminate the string   
    return ndx;  
}


/*
// Mesure la tension de la batterie qui alimente l'Arduino
// en utilisant cette tension comme référence et en mesurant
// la référence interne à 1,1 V avec le convertisseur
// Analogique-Numérique
// **
// **
float getBatteryVoltage(){
  float batteryVoltage=0.0;
  
  ADCSRA =  bit(ADEN);   // Active le convertisseur ADC
  ADCSRA |= bit (ADPS0) |  bit (ADPS1) | bit (ADPS2);  // Prescaler de 128
   
  ADMUX = bit (REFS0); // Positionne AVcc (tension d'alimentation du convertisseur) comme tension de référence
  ADMUX |= bit (MUX3) | bit (MUX2) | bit (MUX1); // Le canal d'entrée de l'ADC est mis sur la référence interne de 1.1V
  delay (10);                       // Laissons la mesure se stabiliser
  bitSet (ADCSRA, ADSC);            // Demarrons la conversion  
  while (bit_is_set(ADCSRA, ADSC))  // Attendons que la conversion soit finie
    { }
 
  batteryVoltage = InternalReferenceVoltage / ADC * 1024.0;
  Serial.print("ADC=");
  Serial.print(ADC);
  Serial.print(" , Voltage=");
  Serial.println(batteryVoltage);
  return(batteryVoltage); 
}
*/

// searches for the string sfind in the string str
// returns 1 if string found
// returns 0 if string not found
int StrContains(char *str, const char *sfind)
{
    unsigned int  found = 0;
    unsigned int  index = 0;
    unsigned int len;


    len = strlen(str);   

    if (strlen(sfind) > len) {
        return 0;
    }
    while (index < len) {

        if (str[index] == sfind[found]) {
            found++;
            if (strlen(sfind) == found) {
                Serial.println("found");
                return 1;
            }
        }
        else {
            found = 0;
        }
        index++;
    }

    return 0;
}

void enableAT() {
  delay(250);
  digitalWrite(HC12SETPIN,LOW);   
  delay(500);
}

void disableAT() {
  delay(250);
  digitalWrite(HC12SETPIN,HIGH);   
  delay(500);
}

void SleepHC12() {

  // Positionne le HC12 en mode programmation (AT) et envoie la commande "AT+SLEEP"
  enableAT();

  // clean the buffer
  readSerialHC12();

  HC12Serial.println("AT+SLEEP");
  delay(250);
   
  // Vérifie la réponse de la commande, doit être "OK+SLEEP"
  if(HC12Serial.available() > 0)  {
    readSerialHC12();
    //Serial.println(messageRx);
    if (StrContains(messageRx, "OK")==0) {
      Serial.println("Error to get HC12 to sleep");
      }
    else { Serial.println("Going to sleep"); }
    }

  disableAT();
}
 
// Sors le HC12 du mode veille en lui envoyant la commande AT
// **
// **


void checkSerial() {  // try different UART Baud rate and modify the HC12ok flag
  // set the possible UART baud rates
  long Baud_Rates[] = {1200,9600};
  int BR_len=sizeof(Baud_Rates)/sizeof(Baud_Rates[0]);

  // Set PIN for AT commmands
  enableAT();

  HC12ok=0;
  byte i = 0;
  
  while (( i < BR_len)&&( HC12ok==0 )){
      Serial.println(Baud_Rates[i]);
      
      // reset baud rate
      HC12Serial.begin(Baud_Rates[i]);         
      HC12Serial.setTimeout(500);

      //clean the serial buffer
      delay (1000);
      readSerialHC12();
      
      // send AT command
      HC12Serial.println("AT+RB");
      delay(1000);
      
      // Vérifie la réponse de la commande, doit être "OK"
      if(HC12Serial.available() > 0)  { // send data FROM HC-12
        readSerialHC12();
        Serial.println(messageRx); 

        if (StrContains(messageRx, "OK")>0) { HC12ok=1; } 
        } 

      else { 
        // Serial not listening
        Serial.println("NO answer from UART");
      }

  
   i++;
  }

    // Positionne le HC12 en mode normal    
  disableAT();

  Serial.println("END UART check");
}

void wakeupHC12() {

  enableAT();

  //clean the serial buffer
  readSerialHC12();


  HC12Serial.println("AT");
  delay(250);

  if(HC12Serial.available() > 0)  { // send data FROM HC-12
    HC12ok=1;
    readSerialHC12();
    Serial.println(messageRx);
    if (StrContains(messageRx, "OK")==0) {
      Serial.println("Error in wake-up the HC-12");
      }
    else { Serial.println("Wake-up"); }
    }  
  else { 
    // Serial not listening
    // restart serial
    Serial.println("Reset");
    delay(5000);
    
    resetFunc(); //call reset 
    //HC12Serial.end();
    // set both pins to low
    //pinMode(HC12TXPIN, OUTPUT);
    //pinMode(HC12RXPIN, OUTPUT);
    //digitalWrite(HC12TXPIN, LOW);
    //digitalWrite(HC12RXPIN, LOW);
    //delay(1000);

    // reset serial
    /*
    SoftwareSerial HC12Serial(HC12TXPIN, HC12RXPIN);  
    HC12Serial.begin(9600);         
    HC12Serial.setTimeout(300);
    HC12ok=0;
    */
  }
  
  // Positionne le HC12 en mode normal    
  disableAT();

}


 
// Utility algorithm

int CompUntilSeparator(char* buffer , char* compare, unsigned int &i, char sepa) {
        unsigned int insize = strlen(buffer);
        unsigned int compsize = strlen(compare);
        unsigned int j=0;
        int found=1;
        while ( (buffer[i]!= sepa) && (i<insize)){
          if (buffer[i]!=compare[j]) {
            found=0;
          }
          i++;
          if (j<compsize) {
          j++;
          }
        }
        if ((found==1)&&(j>0)){ 
          return 1;
        }
        return 0;
}

// chiphering algorithm XORchipher

char* XORENC(char* in, char* key, unsigned int insize){

  // if the Zero char is encoded then the string will be terminated according to the byte string convention which terminates with \x00
  // this is the reason why teh size is imported and exported

  //Serial.println(insize);
  int keysize = strlen(key);
  for(unsigned int x=0; x<insize; x++){
      in[x]=(in[x]^key[x % keysize]);
      //Serial.print(in[x],HEX);
      //Serial.print("-");

  }
  //Serial.println("***");


  return in;
}
 

void sendWait(const char* ATcmd) {

  delay(250);
  // set the Channel --------------
  HC12Serial.println(ATcmd);   
  Serial.println(ATcmd);    
  delay(100);
 
  if(HC12Serial.available() > 0)  {
    readSerialHC12();
    Serial.println(messageRx);       
    if (StrContains(messageRx, "OK")==0) {
      Serial.print("AT command Error: ");
      Serial.println(ATcmd);
   
      }
    }


}


// Configuration 
// -------------
void setup() {
 
  wdt_disable();

  pinMode(HC12TXPIN, INPUT);    // TX du HC12 est une PIN en entrée sur l'arduino
  pinMode(HC12RXPIN, OUTPUT);   // RX du HC12 est une PIN en sortie sur l'arduino
  pinMode(HC12SETPIN,OUTPUT);   // SET du HC12 est une PIN en sortie sur l'arduino
   
  Serial.begin(9600);
  Serial.setTimeout(300);
  Serial.println("Here we are");

  //HC12Serial.begin(1200);         
  //HC12Serial.setTimeout(500);
  checkSerial();   // modify the HC12ok flag and set the serial baud rate

  enableAT();

  // clean serial buffer
  readSerialHC12();

  // set the TX power --------------
  sendWait(AT_TX_power);

  // set the Channel --------------
  sendWait(AT_Channel);

  // set the UART baud Rate to 1200 (which is supported both by F3 ad F4) --------------
  sendWait("AT+B1200");

  // set the Tx Mode --------------
  sendWait(AT_TX_mode);

  delay(500);

    // reset baud rate
  HC12Serial.begin(1200);         
  HC12Serial.setTimeout(500);

  
  disableAT();
  pinMode(LED_BUILTIN, OUTPUT);
 
  // Slowwire initialization

  slowwireInit();

  //Initializa random number using seeds from floating pin reading
  // Keep A= pin Afloat
  randomSeed(analogRead(A0));
  Serial.print("Random Seed=");
  Serial.println(analogRead(A0));

}
 
void loop() {
 



  uint8_t sensorinde=0;
  // real all the data from the Sensors
  for (sensorinde=0 ; sensorinde<sw_sensor_num; sensorinde++) {
    if (strlen(slowwire[sensorinde].nameID)>0) {
      slowwireRead(sensorinde);
      delay(1000);
    }
   
  }
  // wake up HC12
  wakeupHC12();  // this checks also serial availability 
  delay(500);

  // check serial connection with HC12
  if (HC12ok >0) {

    //char datastr[10];
    //ltoa(slowwire[sensorinde].humidity, datastr, 10);

    // Use LED to signal the start of the transmission
    digitalWrite(LED_BUILTIN, HIGH);  
      


    for (sensorinde=0 ; sensorinde<sw_sensor_num; sensorinde++) {


      if ((strlen(slowwire[sensorinde].nameID)>0)&&(slowwire[sensorinde].humidity>-1)) {   // remember to correct this condition
        // Message made as nameID:timestamp:datastr



        sprintf(timestamp, "%lu",millis());


        // retry sequence in case ACK is not received try to send the message again

        int retrycount=0;
        int ACKok=0;
        while ((ACKok==0)&&(retrycount<3))  {
          retrycount++;
          
          // read serila buffer
          readSerialHC12();
          
          sprintf(message, "{%s:%s:%ld:}",slowwire[sensorinde].nameID, timestamp ,slowwire[sensorinde].humidity);
          
          Serial.println("the message");
          Serial.println(message);    

          int msgsize = strlen(message);
          HC12Serial.write(XORENC(message,cipherkey,msgsize),msgsize);  // use write with size to include transmission of \x00, if using char* string, this cannot be transmitted because is th string termination

          // Wait for positive answer from the other side
          // In case no answer, it assumes there has been a collision, will resend the message after a random number of seconds
            // verify the presence of data
          unsigned int count=0;
          while ((HC12Serial.available() == 0)&&(count<100))  {
          delay(100);
          count++;
          }

          // start reading the HC-12 serial port to look kfor ACK messages from the other side
          if (HC12Serial.available() > 0) {
            // read serila buffer
            unsigned int msgsize=readSerialHC12();   
            XORENC(messageRx,cipherkey,msgsize);  // buffer is now changed    
            // search for the { 
            Serial.println(messageRx);
            unsigned int i=0;
            if (messageRx[i]== '{') {
              // Split the char array buffer in Strings        
              int okname;
              i++;
              okname=CompUntilSeparator(messageRx,slowwire[sensorinde].nameID,i,':');
              //Serial.println(okname);
              i++;
              int okstamp;
              okstamp=CompUntilSeparator(messageRx,timestamp,i,':'); 
              //Serial.println(okstamp);
              i++;
              int okmsg;
              char oks[3]="OK";
              okmsg=CompUntilSeparator(messageRx,oks,i,':');
              //Serial.println(okmsg);

              if ((okname==1)&&(okstamp==1)&&(okmsg==1)) {
                  ACKok=1;
                  Serial.println("ACK received succesfully");
              } 



            }

          }

          // check if the ACK has NOT been succesfully received
          if (ACKok==0) {
                  Serial.println("ACK NOT received, retry");
                  // calculate random delay
                  delay(random(6000,60000));  // begin and end of the range in mSec 
            }

        }  

        delay(2000);
      } // if
    } // for

    // switch off the LED
    digitalWrite(LED_BUILTIN, LOW);  

    SleepHC12();        
 
  } // if goON


  // Set Arduino to Sleep for a period
  Sleep.deeplyFor(SLEEP_TIME_mSEC);


}