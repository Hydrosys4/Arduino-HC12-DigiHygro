#include "../SimpleSleep.h"

#if defined(SS_ATTiny13)

  /* There is nothing to be done here, the standard methods defined in avr.cpp will work for us. */
  
#endif