
// Software Version V1.2 (added AT commands setting)
// Software Version V1.3 (Support FU4 UART baudrate 1200 as preferred)
// Software Version V1.4 (fixed the case of transmission with char=\x00)
// Software Version V1.5 (Made for actuators, no sleep)
// Software Version V1.6 (enable option for the relay Active LOW)

#include "Arduino.h"
#include "SoftwareSerial.h"


void(* resetFunc) (void) = 0;//declare reset function at address 0

// ################################################################################################################
// HC12 Arduino PIN Setting part  *********************************************************************************
#define HC12RXPIN   2           // PIN 2 to RX du HC12
#define HC12TXPIN   3          // PIN 3 to TX du HC12
#define HC12SETPIN  4           // PIN 4 to SET du HC12

// range of pins used for the actuator
#define MINPIN   5           // MIN pin number should be 5 as the previous are used by the HC12
#define MAXPIN   13          //  MAX can be up to 13 in the arduino Nano and Micro

const int PinArrayLen= MAXPIN-MINPIN;

 
// End Setting ****************************************************************************************************
// ################################################################################################################

SoftwareSerial HC12Serial(HC12TXPIN, HC12RXPIN);  
// battery voltage reference
const float InternalReferenceVoltage = 1.105; 

// serial receiver buffer
const byte numChars = 45;   // softwareserial buffer should be 64 so not exceeding the buffer size
char messageRx[numChars+1]="";   // an array to store the received data


// slowwire START 

// global variables


// ################################################################################################################
// Actuator name and chiper key  part  ********************************************************

char cipherkey[]="default";   // chipher key

char actuatorName[]="Relay1";  // the identifier of the actuator in this device

int activeLow=1;  // this is 1 whent the relay logic is active low, otherwise set to 0

// wireless parameters Setting

char AT_TX_mode[]="AT+FU4"; // format AT+FUx possible values "AT+FU3","AT+FU4" (FU4 is used for long distance transmssion)
char AT_TX_power[]="AT+P3"; // format  AT+Px where X ranges from 1 to 8
char AT_Channel[]="AT+C003"; // format  AT+Cxxx where xxx range from 001 to 100


// End Setting ****************************************************************************************************
// ################################################################################################################


int HC12ok = 0;

char message[50]="";
char timestamp[14]="";




unsigned int readSerialHC12() {
    unsigned int ndx = 0;
    unsigned int count = 0;
    char rc;
    while ((HC12Serial.available() > 0)&&(count<200)) {
      count++;
      rc = HC12Serial.read();
      if (ndx < numChars) {      
        //Serial.println(rc);
        messageRx[ndx] = rc;
        ndx++;
        }
      delay(50);
        
    }
    messageRx[ndx] = '\0'; // terminate the string   
    return ndx;  
}



// searches for the string sfind in the string str
// returns 1 if string found
// returns 0 if string not found
int StrContains(char *str, const char *sfind)
{
    unsigned int  found = 0;
    unsigned int  index = 0;
    unsigned int len;


    len = strlen(str);   

    if (strlen(sfind) > len) {
        return 0;
    }
    while (index < len) {

        if (str[index] == sfind[found]) {
            found++;
            if (strlen(sfind) == found) {
                Serial.println("found");
                return 1;
            }
        }
        else {
            found = 0;
        }
        index++;
    }

    return 0;
}

void enableAT() {
  delay(250);
  digitalWrite(HC12SETPIN,LOW);   
  delay(500);
}

void disableAT() {
  delay(250);
  digitalWrite(HC12SETPIN,HIGH);   
  delay(500);
}

void SleepHC12() {

  // Positionne le HC12 en mode programmation (AT) et envoie la commande "AT+SLEEP"
  enableAT();

  // clean the buffer
  readSerialHC12();

  HC12Serial.println("AT+SLEEP");
  delay(250);
   
  // Vérifie la réponse de la commande, doit être "OK+SLEEP"
  if(HC12Serial.available() > 0)  {
    readSerialHC12();
    //Serial.println(messageRx);
    if (StrContains(messageRx, "OK")==0) {
      Serial.println("Error to get HC12 to sleep");
      }
    else { Serial.println("Going to sleep"); }
    }

  disableAT();
}
 
// Sors le HC12 du mode veille en lui envoyant la commande AT
// **
// **


void checkSerial() {  // try different UART Baud rate and modify the HC12ok flag
  // set the possible UART baud rates
  long Baud_Rates[] = {1200,9600};
  int BR_len=sizeof(Baud_Rates)/sizeof(Baud_Rates[0]);

  // Set PIN for AT commmands
  enableAT();

  HC12ok=0;
  byte i = 0;
  
  while (( i < BR_len)&&( HC12ok==0 )){
      Serial.println(Baud_Rates[i]);
      
      // reset baud rate
      HC12Serial.begin(Baud_Rates[i]);         
      HC12Serial.setTimeout(500);

      //clean the serial buffer
      delay (1000);
      readSerialHC12();
      
      // send AT command
      HC12Serial.println("AT+RB");
      delay(1000);
      
      // Vérifie la réponse de la commande, doit être "OK"
      if(HC12Serial.available() > 0)  { // send data FROM HC-12
        readSerialHC12();
        Serial.println(messageRx); 

        if (StrContains(messageRx, "OK")>0) { HC12ok=1; } 
        } 

      else { 
        // Serial not listening
        Serial.println("NO answer from UART");
      }

  
   i++;
  }

    // Positionne le HC12 en mode normal    
  disableAT();

  Serial.println("END UART check");
}

void wakeupHC12() {

  enableAT();

  //clean the serial buffer
  readSerialHC12();


  HC12Serial.println("AT");
  delay(250);

  if(HC12Serial.available() > 0)  { // send data FROM HC-12
    HC12ok=1;
    readSerialHC12();
    Serial.println(messageRx);
    if (StrContains(messageRx, "OK")==0) {
      Serial.println("Error in wake-up the HC-12");
      }
    else { Serial.println("Wake-up"); }
    }  
  else { 
    // Serial not listening
    // restart serial
    Serial.println("Reset");
    delay(5000);
    
    resetFunc(); //call reset 
    //HC12Serial.end();
    // set both pins to low
    //pinMode(HC12TXPIN, OUTPUT);
    //pinMode(HC12RXPIN, OUTPUT);
    //digitalWrite(HC12TXPIN, LOW);
    //digitalWrite(HC12RXPIN, LOW);
    //delay(1000);

    // reset serial
    /*
    SoftwareSerial HC12Serial(HC12TXPIN, HC12RXPIN);  
    HC12Serial.begin(9600);         
    HC12Serial.setTimeout(300);
    HC12ok=0;
    */
  }
  
  // Positionne le HC12 en mode normal    
  disableAT();

}


 
// Utility algorithm

int CompUntilSeparator(char* buffer , char* compare, unsigned int &i, char sepa) {
        unsigned int insize = strlen(buffer);
        unsigned int compsize = strlen(compare);
        unsigned int j=0;
        int found=1;
        while ( (buffer[i]!= sepa) && (i<insize)){
          if (buffer[i]!=compare[j]) {
            found=0;
          }
          i++;
          if (j<compsize) {
          j++;
          }
        }
        if ((found==1)&&(j>0)){ 
          return 1;
        }
        return 0;
}

// Utility algorithm

int extractUntilSeparator(char* buffer ,char* out, unsigned int &i, char sepa) {
    unsigned int insize = strlen(buffer);
    unsigned int j=0;
    int found=0;
    while ( (buffer[i]!= sepa) && (i<insize)){
        out[j]=buffer[i];
        i++;
        j++;
      }
    if (buffer[i]== sepa){ 
      found = 1;
    } else { 
      j=0; 
    }
    out[j] = '\0'; // terminate the string 
    return found;
}

// chiphering algorithm XORchipher

char* XORENC(char* in, char* key, unsigned int insize){

  // if the Zero char is encoded then the string will be terminated according to the byte string convention which terminates with \x00
  // this is the reason why teh size is imported and exported

  //Serial.println(insize);
  int keysize = strlen(key);
  for(unsigned int x=0; x<insize; x++){
      in[x]=(in[x]^key[x % keysize]);
      //Serial.print(in[x],HEX);
      //Serial.print("-");

  }
  //Serial.println("***");


  return in;
}
 

void sendWait(const char* ATcmd) {

  delay(250);
  // set the Channel --------------
  HC12Serial.println(ATcmd);   
  Serial.println(ATcmd);    
  delay(100);
 
  if(HC12Serial.available() > 0)  {
    readSerialHC12();
    Serial.println(messageRx);       
    if (StrContains(messageRx, "OK")==0) {
      Serial.print("AT command Error: ");
      Serial.println(ATcmd);
   
      }
    }


}

// global variable to store the status of the outputs

unsigned long starttimePIN[PinArrayLen+1];
unsigned long timedurationPIN[PinArrayLen+1];


void digitalWriteHL(int pin, int val) {
    if (activeLow>0) {
        if (val==0) {
          val=1;
        } else {
          val=0;
        }
    }
    digitalWrite(pin,val);

}

void initPINs() {
  for(int i=0; i<PinArrayLen+1; i++){
       // set pin to output
      pinMode(i+MINPIN,OUTPUT);
      // set pin to LOW
      digitalWriteHL(i+MINPIN,LOW);
      // init time and duration
      starttimePIN[i]=millis();
      timedurationPIN[i]=0;
  }
}
    

void startPINpulse(const char* pinstr, const char* duration) {

  // convert from string to long 
  long pin = strtol(pinstr, NULL, 10);
  if ((pin>=MINPIN)&&(pin<=MAXPIN)) {
    // pin in range
    starttimePIN[pin-MINPIN]=millis();
    timedurationPIN[pin-MINPIN]=strtol(duration, NULL, 10)*1000;
    if (duration>0) {
      // set pin to HIGH
      digitalWriteHL(pin,HIGH); 
      Serial.print("Start Pulse PIN=");
      Serial.println(pinstr);
    }

  }

}

void timerPINstop() {
  unsigned long time;
  for(int i=0; i<PinArrayLen+1; i++){
      if (timedurationPIN[i]>0) {
        time = millis();
        if(time - starttimePIN[i] >= timedurationPIN[i])
        {
          // do something
          // set pin to LOW
          digitalWriteHL(i+MINPIN,LOW);
          starttimePIN[i] = time;
          timedurationPIN[i] = 0;
          Serial.print("Stop Pulse by Timer PIN=");
          Serial.println(i+MINPIN);
        }        
      }
  }
}

void stopPINpulse(const char* pinstr) {

  // convert from string to long 
  long pin = strtol(pinstr, NULL, 10);
  if ((pin>=MINPIN)&&(pin<=MAXPIN)) {
    // pin in range
    starttimePIN[pin-MINPIN]=millis();
    timedurationPIN[pin-MINPIN]=0;
    digitalWriteHL(pin,LOW); 
    Serial.print("Stop Pulse by Command PIN=");
    Serial.println(pinstr);

  }
}


// Configuration 
// -------------
void setup() {
 

  pinMode(HC12TXPIN, INPUT);    // TX du HC12 est une PIN en entrée sur l'arduino
  pinMode(HC12RXPIN, OUTPUT);   // RX du HC12 est une PIN en sortie sur l'arduino
  pinMode(HC12SETPIN,OUTPUT);   // SET du HC12 est une PIN en sortie sur l'arduino
   
  // init output pins and the status array
  initPINs();

  Serial.begin(9600);
  Serial.setTimeout(300);
  Serial.println("Here we are");

  //HC12Serial.begin(1200);         
  //HC12Serial.setTimeout(500);
  checkSerial();   // modify the HC12ok flag and set the serial baud rate

  enableAT();

  // clean serial buffer
  readSerialHC12();

  // set the TX power --------------
  sendWait(AT_TX_power);

  // set the Channel --------------
  sendWait(AT_Channel);

  // set the UART baud Rate to 1200 (which is supported both by F3 ad F4) --------------
  sendWait("AT+B1200");

  // set the Tx Mode --------------
  sendWait(AT_TX_mode);

  delay(500);

    // reset baud rate
  HC12Serial.begin(1200);         
  HC12Serial.setTimeout(500);

  
  disableAT();
  pinMode(LED_BUILTIN, OUTPUT);
 

}
 
void loop() {
 

  // check serial connection with HC12
  if (HC12ok >0) {


          // start reading the HC-12 serial port to look kfor ACK messages from the other side
          if (HC12Serial.available() > 0) {
            // Use LED to signal the start of the transmission
            digitalWrite(LED_BUILTIN, HIGH); 
            // read serila buffer
            unsigned int msgsize=readSerialHC12();   
            XORENC(messageRx,cipherkey,msgsize);  // buffer is now changed    
            // search for the { 
            Serial.println(messageRx);
            unsigned int i=0;
            if (messageRx[i]== '{') {
              // Split the char array buffer in Strings        
              int okname;
              i++;
              // check if the right address
              okname=CompUntilSeparator(messageRx,actuatorName,i,'/');
              //Serial.println(okname);

              if (okname>0) {  // the name matches
                i++;
                char action[14];
                extractUntilSeparator(messageRx,action,i,'/'); 
                //Serial.println(action);
                i++;
                char pinstr[3];
                extractUntilSeparator(messageRx,pinstr,i,':');
                //Serial.println(pinstr);
                i++;
                char millis[18];
                extractUntilSeparator(messageRx,millis,i,':');
                //Serial.println(millis);
                i++;
                char duration[10];
                extractUntilSeparator(messageRx,duration,i,':');
                //Serial.println(duration);

                // reply with ACK

                          
                // read serila buffer
                readSerialHC12();
                sprintf(message, "{%s/%s/%s:%s:OK:}",actuatorName, action ,pinstr,millis);
                Serial.println("the message");
                Serial.println(message);    
                int msgsize = strlen(message);
                HC12Serial.write(XORENC(message,cipherkey,msgsize),msgsize);  // use write with size to include transmission of \x00, if using char* string, this cannot be transmitted because is th string termination


                // switch off the LED
                digitalWrite(LED_BUILTIN, LOW); 
                if (StrContains(action, "Start")){
                  // Start Actuator pulse
                  startPINpulse(pinstr, duration);
                }
                if (StrContains(action, "Stop")){
                  // Stop Actuator pulse
                  stopPINpulse(pinstr);
                }


              }


            }

          }

    // check if the pin exceed the pulse timer and switch them off
    timerPINstop();
    
 


  } // if goON




}