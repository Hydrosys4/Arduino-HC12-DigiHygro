#ifndef SS_ATtinyX4_h
#define SS_ATtinyX4_h

 #if defined (__AVR_ATtiny84__) || defined (__AVR_ATtiny44__) || defined (__AVR_ATtiny24__) \
 || defined (__AVR_ATtiny84A__) || defined (__AVR_ATtiny44A__) || defined (__AVR_ATtiny24A__)
  
    #define SS_SUPPORTED_CHIP
    #define SS_ATTinyX4
  
  #endif    
#endif